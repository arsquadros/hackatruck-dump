//
//  jp_desafio12App.swift
//  jp_desafio12
//
//  Created by Turma02-16 on 02/04/25.
//

import SwiftUI

@main
struct jp_desafio12App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

//
//  Pagina3View.swift
//  jp_desafio06
//
//  Created by Turma02-16 on 21/03/25.
//

import SwiftUI

struct Pagina3View: View {
    @Environment(\.dismiss) var dismiss

    var body: some View {
        Button("Press to dismiss") {
            dismiss()
        }
        .font(.title)
        .padding()
        .background(.black)
    }
}

#Preview {
    Pagina3View()
}

//
//  CinzaView.swift
//  jp_desafio05
//
//  Created by Turma02-16 on 21/03/25.
//

import SwiftUI

struct CinzaView: View {
    var body: some View {
        VStack{
            Image(systemName: "paintpalette").resizable().frame(
                width:200, height: 200
            )
        }.frame(
            maxWidth: .infinity,
            maxHeight: .infinity
        ).background(.gray)
    }
}

#Preview {
    CinzaView()
}

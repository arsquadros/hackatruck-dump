//
//  File.swift
//  jp_desafio09
//
//  Created by Turma02-16 on 29/03/25.
//

import Foundation

jp_desafio09.PersonagemModel(
    id: "9c8ce8c7-ae0a-4646-920f-09c071862f10",
    name: Optional("James Potter"),
    alternate_names: Optional(["James Sirius Potter"]),
    species: Optional("human"),
    gender: Optional("male"),
    house: Optional("Gryffindor"),
    dateOfBirth: nil,
    yearOfBirth: nil,
    wizard: Optional(true),
    ancestry: Optional("half-blood"),
    eyeColour: Optional(""),
    hairColour: Optional(""),
    wand: jp_desafio09.Varinha(wood: Optional(""), core: Optional(""), length: nil),
    patronus: Optional(""),
    hogwartsStudent: Optional(true),
    hogwartsStaff: Optional(false),
    actor: Optional("Will Dunn"),
    alternate_actors: Optional([]),
    alive: Optional(true),
    image: Optional(""))
)

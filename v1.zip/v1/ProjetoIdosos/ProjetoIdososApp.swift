//
//  ProjetoIdososApp.swift
//  ProjetoIdosos
//
//  Created by Turma02-16 on 02/04/25.
//

import SwiftUI

@main
struct ProjetoIdososApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

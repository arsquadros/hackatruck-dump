//
//  Pagina2View.swift
//  jp_desafio06
//
//  Created by Turma02-16 on 21/03/25.
//

import SwiftUI

struct Pagina2View: View {
    var body: some View {
        VStack {
            Text("Pagina2").font(.largeTitle).bold()
            
            Spacer()
            
            VStack {
                Text("texto")
                Text("texto").font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/).bold()
                
                NavigationLink(destination: Pagina1View()) {
                    Text("Pagina1").frame(
                        width: 100, height: 30
                    ).background(.red).cornerRadius(10)
                }
            }
            
            Spacer()
        }
    }
}

#Preview {
    Pagina2View()
}

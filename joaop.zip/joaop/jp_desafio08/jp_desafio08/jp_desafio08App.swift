//
//  jp_desafio08App.swift
//  jp_desafio08
//
//  Created by Turma02-16 on 25/03/25.
//

import SwiftUI

@main
struct jp_desafio08App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

//
//  MusicaView.swift
//  jp_desafio07
//
//  Created by Turma02-16 on 24/03/25.
//

import SwiftUI

struct MusicaView: View {
    @State var musica:String?
    @State var artista:String?
    @State var capa:String?

    var body: some View {
        VStack {
            AsyncImage(
                url: URL(
                    string: capa!
                ),
                content: { image in
                    image.resizable().frame(
                        width: 350, height: 350, alignment: .center
                    ).padding().foregroundColor(.white)
                }, placeholder: {
                    Image(
                        systemName: "questionmark.app.fill"
                    ).resizable().frame(
                        width: 350, height: 350, alignment: .center
                    ).padding().foregroundColor(.white)
                }
            )
            
            Text(musica!).font(.title).foregroundColor(.white)
            Text(artista!).font(.title2).foregroundColor(.white)
            
            Spacer()
            
            HStack {
                Image(systemName: "shuffle").resizable().frame(
                    width: 30, height: 30
                ).padding([.leading, .trailing], 15).foregroundColor(.white)
                Image(systemName: "backward.end.fill").resizable().frame(
                    width: 35, height: 35
                ).padding([.leading, .trailing], 15).foregroundColor(.white)
                Image(systemName: "play.fill").resizable().frame(
                    width: 40, height: 40
                ).padding([.leading, .trailing], 15).foregroundColor(.white)
                Image(systemName: "forward.end.fill").resizable().frame(
                    width: 35, height: 35
                ).padding([.leading, .trailing], 15).foregroundColor(.white)
                Image(systemName: "repeat").resizable().frame(
                    width: 30, height: 30
                ).padding([.leading, .trailing], 15).foregroundColor(.white)
            }.padding(.bottom, 60)
        }.frame(maxWidth: .infinity).background(
            LinearGradient(gradient: Gradient(
                colors: [.blue, .black, .black]
            ), startPoint: .top, endPoint: .bottom)
        )
    }
}

#Preview {
    MusicaView(musica:"", artista:"", capa:"")
}

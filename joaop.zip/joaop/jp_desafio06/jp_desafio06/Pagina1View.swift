//
//  Pagina1View.swift
//  jp_desafio06
//
//  Created by Turma02-16 on 21/03/25.
//

import SwiftUI

struct Pagina1View: View {
    var body: some View {
        Text("Pagina1").font(.largeTitle).bold()
        
        Spacer()
        
        VStack{
            Text("texto").font(.title)
            Text("texto")
        }.frame(
            width:250, height: 100
        ).background(.red).cornerRadius(20)
        
        Spacer()
    }
}

#Preview {
    Pagina1View()
}

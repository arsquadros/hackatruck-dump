//
//  Reminder.swift
//  ProjetoIdosos
//
//  Created by Turma02-16 on 02/04/25.
//

import SwiftUI

struct ReminderAdd: View {
    @State var datetime:Date
    @State var title:String
    @State var description:String
    @State var repeatable:Bool
    @State var hour:Int
    @State var minute:Int
    @State var second:Int

    var body: some View {
        VStack {
            TextField("Título do Lembrete", text: $title)
                .font(.largeTitle)
                .multilineTextAlignment(.center)
            HStack {
                VStack {
                    Button("^") {
                        hour = (hour + 1)%24
                    }
                    Text("\(hour)").font(.largeTitle)
                    Button("v") {
                        hour = (hour + (24 - 1))%24
                    }
                }
                Text(":").font(.largeTitle)
                VStack {
                    Button("^") {
                        minute = (minute + 1)%60
                    }
                    Text("\(minute)").font(.largeTitle)
                    Button("v") {
                        minute = (minute + (60 - 1))%60
                    }
                }
                Text(":").font(.largeTitle)
                VStack {
                    Button("^") {
                        second = (second + 1)%60
                    }
                    Text("\(second)").font(.largeTitle)
                    Button("v") {
                        second = (second + (60 - 1))%60
                    }
                }
            }
            TextEditor(text: $description)
                .frame(height: 100)
                .border(.black)
                .padding()
            Toggle("Repetir lembrete", isOn: $repeatable)
            if repeatable {
                // opcoes de repeticao
            }
            
            Spacer()
            
            HStack {
                Button("Concluir") {
                }.font(.title).bold()
                    .multilineTextAlignment(.leading)
                Button("Deletar") {
                }.font(.title).bold()
                    .multilineTextAlignment(.trailing)
                    .foregroundColor(.red)
            }
        }.padding()
    }
}

struct ReminderView: View {
    @State var add:Bool = false
    private let timeFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        return formatter
    }()
    private let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        return formatter
    }()
    @State var alarmes:[Reminder] = [
        Reminder(
            id:"1",
            title: "tit",
            description: "desc",
            datetime: Date(),
            isRepeatable: false
        ),
        Reminder(
            id:"2",
            title: "tit",
            description: "desc",
            datetime: Date(),
            isRepeatable: true
        ),
        Reminder(
            id:"3",
            title: "tit",
            description: "desc",
            datetime: Date(),
            isRepeatable: false
        ),
        Reminder(
            id:"4",
            title: "tit",
            description: "desc",
            datetime: Date(),
            isRepeatable: true
        ),
        Reminder(
            id:"5",
            title: "tit",
            description: "desc",
            datetime: Date(),
            isRepeatable: false
        ),
        Reminder(
            id:"6",
            title: "tit",
            description: "desc",
            datetime: Date(),
            isRepeatable: true
        ),
        Reminder(
            id:"7",
            title: "tit",
            description: "desc",
            datetime: Date(),
            isRepeatable: false
        )
    ]
    
    var body: some View {
        NavigationStack {
            VStack {
                Text("Alarmes Cadastrados")
                    .font(.largeTitle)
                    .bold()

                List {
                    ForEach(alarmes) { alarme in
                        HStack(alignment: .center) {
                            NavigationLink(destination: ReminderAdd(
                                datetime: alarme.datetime,
                                title: alarme.title,
                                description: alarme.description,
                                repeatable: alarme.isRepeatable,
                                hour: Int(Calendar.current.component(
                                    .hour, from: alarme.datetime
                                )),
                                minute: Int(Calendar.current.component(
                                    .minute, from: alarme.datetime
                                )),
                                second: Int(Calendar.current.component(
                                    .second, from: alarme.datetime
                                ))
                            )) {
                                VStack {
                                    Text(alarme.title)
                                        .font(.title)
                                        .padding(.leading, 10)
                                        .multilineTextAlignment(.leading)
                                    
                                    Text(timeFormatter.string(from: alarme.datetime))
                                        .font(.title)
                                        .padding(.leading, 10)
                                        .multilineTextAlignment(.leading)
                                }
                            }.frame(height: 100)
                        }.padding([.trailing], 10)
                    }
                }
                
                NavigationLink(destination: ReminderAdd(
                    datetime: Date(),
                    title: "",
                    description: "",
                    repeatable: false,
                    hour: Int(Calendar.current.component(
                        .hour, from: Date()
                    )),
                    minute: Int(Calendar.current.component(
                        .minute, from: Date()
                    )),
                    second: 0
                )) {
                    Text("Adicionar lembrete")
                }
            }.font(.title).bold().padding(.bottom, 15)
        }
    }
}

#Preview {
    ReminderView()
}

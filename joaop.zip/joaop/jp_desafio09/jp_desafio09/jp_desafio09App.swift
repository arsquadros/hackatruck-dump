//
//  jp_desafio09App.swift
//  jp_desafio09
//
//  Created by Turma02-16 on 26/03/25.
//

import SwiftUI

@main
struct jp_desafio09App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

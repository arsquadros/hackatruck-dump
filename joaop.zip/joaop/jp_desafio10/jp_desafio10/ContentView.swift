//
//  ContentView.swift
//  jp_desafio10
//
//  Created by Turma02-16 on 27/03/25.
//

import SwiftUI

struct ObjetoModel: Decodable,Hashable {
    var nome:String?
    var cor:String?
}

struct ObjetoModelPost: Codable {
    var id:String?
    var nome:String?
    var cor:String?
}

class Objeto: ObservableObject {
    @Published var objetos:[ObjetoModel] = []

    func get() {
        guard let url = URL(string: "127.0.0.1:1880/a_leitura/") else { return }
        
        let task = URLSession.shared.dataTask(
            with: url
        ) { [weak self] dado, _, erro in
            guard let dado = dado, erro == nil else {
                return
            }
            
            do {
                let parsed = try JSONDecoder().decode(
                    [ObjetoModel].self, from: dado
                )
                
                DispatchQueue.main.async {
                    self!.objetos = parsed
                }
            } catch {
                print(erro!)
            }
        }
        
        task.resume()
    }
    
    func put(id:String, nome:String, cor:String) {
        guard let url = URL(string:  "127.0.0.1:1880/a_atualizacao/") else { return }
        var requisicao = URLRequest(url: url)
        requisicao.setValue("application/json", forHTTPHeaderField: "Content-Type")
        requisicao.httpMethod = "POST"
        
        do {
            var dado = try JSONEncoder().encode(
                ObjetoModelPost(id:id, nome:nome, cor:cor)
            )
            requisicao.httpBody = dado
            requisicao.setValue(
                "application/json",
                forHTTPHeaderField: "Content-Type"
            )
        } catch { return }
        
        let tarefa = URLSession.shared.dataTask(
            with: requisicao
        ) { dado, _, erro in
            
        }
        
        tarefa.resume()
    }
    
    func post(nome:String, cor:String) {
        guard let url = URL(string:  "127.0.0.1:1880/a_atualizacao/") else { return }
        var requisicao = URLRequest(url: url)
        requisicao.setValue("application/json", forHTTPHeaderField: "Content-Type")
        requisicao.httpMethod = "POST"
        
        do {
            var dado = try JSONEncoder().encode(
                ObjetoModelPost(nome:nome, cor:cor)
            )
            requisicao.httpBody = dado
            requisicao.setValue(
                "application/json",
                forHTTPHeaderField: "Content-Type"
            )
        } catch { return }
        
        let tarefa = URLSession.shared.dataTask(
            with: requisicao
        ) { dado, _, erro in
            
        }
        
        tarefa.resume()
    }
    
    func delete(id:String) {
//        "127.0.0.1:1880/o_deletor/"
    }
}

struct Crud:View {
    @Binding var operacao:String?
    @State var nome:String = ""
    @State var cor:String = ""
    @State var id:String = ""
    @State var resposta = Objeto()
    
    var body: some View {
        VStack {
            if(operacao == "post") {
                TextField("Nome do objeto", text: $nome)
                TextField("Cor do objeto", text: $cor)
                Spacer()
                Button(action: {resposta.post(
                    nome:nome, cor:cor
                )}) {
                    Text("Submeter").frame(
                        width: 200, height: 50
                    ).background(.blue).padding(.bottom, 50)
                }
            } else if (operacao == "put") {
                TextField("Id do objeto", text: $id)
                TextField("Nome do objeto", text: $nome)
                TextField("Cor do objeto", text: $cor)
                Spacer()
                Button(action: {
                    resposta.put(id:id, nome:nome, cor:cor)
                }) {
                    Text("Submeter").frame(
                        width: 200, height: 50
                    ).background(.blue).padding(.bottom, 50)
                }
            } else {
                TextField("Id do objeto", text: $id)
                Spacer()
                Button(action: {resposta.delete(id:id)}) {
                    Text("Submeter").frame(
                        width: 200, height: 50
                    ).background(.blue).padding(.bottom, 50)
                }
            }
        }.padding(50)
    }
}

struct ContentView: View {
    @State var resposta = Objeto()
    @State var mostra = false
    @State var operacao:String? = ""
    
    var body: some View {
        VStack {
            List(resposta.objetos, id:\.self) { objeto in
                Text(objeto.nome! + ": " + objeto.cor!)
            }.onAppear() {
                if resposta.objetos.isEmpty {
                    resposta.get()
                }
            }
            
            HStack {
                Button(action: {
                    mostra.toggle()
                    operacao = "post"
                }) {
                    Text("POST").frame(
                        width: 100, height: 50
                    ).background(.blue)
                }.sheet(isPresented: $mostra) {
                    Crud(operacao: $operacao)
                }.tint(.black)
                
                Button(action: {
                    mostra.toggle()
                    operacao = "put"
                }) {
                    Text("PUT").frame(
                        width: 100, height: 50
                    ).background(.blue)
                }.sheet(isPresented: $mostra) {
                    Crud(operacao:$operacao)
                }.tint(.black)
                
                Button(action: {
                    mostra.toggle()
                    operacao = "delete"
                }) {
                    Text("DELETE").frame(
                        width: 100, height: 50
                    ).background(.blue)
                }.sheet(isPresented: $mostra) {
                    Crud(operacao:$operacao)
                }.tint(.black)
            }
        }.padding()
    }
}

#Preview {
    ContentView()
}

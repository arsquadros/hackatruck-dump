//
//  ContentView.swift
//  jp_desafio05
//
//  Created by Turma02-16 on 21/03/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            RosaView().tabItem {
                Label(
                    "Rosa",
                    systemImage: "paintbrush"
                ).padding()
            }
            AzulView().tabItem {
                Label(
                    "Azul",
                    systemImage: "paintbrush.pointed"
                ).padding()
            }
            CinzaView().tabItem {
                Label(
                    "Cinza",
                    systemImage: "paintpalette"
                ).padding()
            }
            ListaView().tabItem {
                Label(
                    "Lista",
                    systemImage: "list.bullet"
                ).padding()
            }
        }.onAppear() {
            UITabBar.appearance().barTintColor = .white
            UITabBar.appearance().backgroundColor = .white
        }
    }
}

#Preview {
    ContentView()
}

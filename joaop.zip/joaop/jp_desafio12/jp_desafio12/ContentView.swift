//
//  ContentView.swift
//  jp_desafio12
//
//  Created by Turma02-16 on 02/04/25.
//

import SwiftUI

struct UmidadeModelo: Decodable {
    let umidade:Float
}

class Umidade:ObservableObject {
    @Published var umidade:Float = -1
    
    func requisita() {
        guard let url = URL(string: "192.168.128.88:1880/a_leitura/") else { return }
        
        let tarefa = URLSession.shared.dataTask(
            with: url
        ) { [weak self] dado, _, erro in
            guard let dado = dado, erro == nil else {
                return
            }
            
            do {
                let parsed = try JSONDecoder().decode(
                    [UmidadeModelo].self, from: dado
                )
                
                DispatchQueue.main.async {
                    self!.umidade = parsed.last?.umidade ?? -1
                    print(type(of: parsed))
                }
            } catch {
                print(erro!)
            }
        }
        
        tarefa.resume()
    }
}

struct ContentView: View {
    @StateObject var resposta:Umidade = Umidade()
    @State var umidade:Float = -1
    var body: some View {
        VStack {
            Text("Umidade: \(resposta.umidade)")
            Spacer()
            Button(action: {
                Task {
                    resposta.requisita()
                    print(resposta.umidade)
                }
            }) {
                Text("Submeter").frame(
                    width: 200, height: 50
                ).border(.blue).padding(.bottom, 50)
            }
        }.padding()
    }
}

#Preview {
    ContentView()
}

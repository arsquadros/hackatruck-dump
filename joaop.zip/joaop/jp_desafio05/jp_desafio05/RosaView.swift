//
//  RosaView.swift
//  jp_desafio05
//
//  Created by Turma02-16 on 21/03/25.
//

import SwiftUI

struct RosaView: View {
    var body: some View {
        VStack{
            Image(systemName: "paintbrush").resizable().frame(
                width:200, height: 200
            ).padding(25).clipShape(Circle())
        }.frame(
            maxWidth: .infinity,
            maxHeight: .infinity
        ).background(.pink)
    }
}

#Preview {
    RosaView()
}

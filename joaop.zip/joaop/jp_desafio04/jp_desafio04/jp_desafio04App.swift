//
//  jp_desafio04App.swift
//  jp_desafio04
//
//  Created by Turma02-16 on 20/03/25.
//

import SwiftUI

@main
struct jp_desafio04App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

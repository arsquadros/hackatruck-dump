//
//  ContentView.swift
//  jp_desafio04
//
//  Created by Turma02-16 on 20/03/25.
//

import SwiftUI
import Foundation

class Animal:Identifiable {
    var id:String {
        self.nome
    }
    
    var nome:String
    var min:Float
    var max:Float
    let cor:Color
    
    init(nome:String, min:Float, max:Float, cor:Color) {
        self.nome = nome
        self.min = min
        self.max = max
        self.cor = cor
    }
}

struct ContentView: View {
    @State private var distancia:Float = 0.0
    @State private var tempo:Float = 0.0
    @State private var velocidade:Float = 0.0
    @State private var background:Color = .gray
    @State private var selecionado:String = ""
    let animais = [
        Animal(nome:"Tartaruga", min:0.0,  max:9.9,  cor:.green),
        Animal(nome:"Elefante",  min:10.0, max:29.9, cor:.blue),
        Animal(nome:"Avestruz",  min:30.0, max:69.9, cor:.orange),
        Animal(nome:"Leao",      min:70.0, max:89.9, cor:.yellow),
        Animal(nome:"Guepardo",  min:90.0, max:130,  cor:.red)
    ]
    @State private var showingAlert:Bool = false
    var body: some View {
        VStack {
            LabeledContent {
                TextField(
                    "Entre com uma distancia: ",
                    value: $distancia,
                    format: .number
                ).multilineTextAlignment(.trailing).keyboardType(.numberPad)
            } label: {
                Text("Distancia")
            }
            
            LabeledContent {
                TextField(
                    "Entre com um tempo: ",
                    value: $tempo,
                    format: .number
                ).multilineTextAlignment(.trailing).keyboardType(.numberPad)
            } label: {
                Text("Tempo")
            }
            
            Button("Calcular") {
                velocidade = distancia / tempo
                for animal in animais {
                    let min:Float = animal.min
                    let max:Float = animal.max
                    if(min <= velocidade && velocidade <= max) {
                        selecionado = animal.nome
                        background = animal.cor
                    }
                }
            }
            
            Spacer()
            
            Text(String(velocidade) + " Km/h")
            
            AsyncImage(
                url: URL(
                    string: "https://loremflickr.com/g/400/400/"+selecionado
                ),
               content: { image in
                   image.resizable().clipShape(Circle()).padding()
               }, placeholder: {
                   Image(
                    systemName: "questionmark.app.fill"
                   ).resizable().clipShape(Circle()).padding()
               }
            ).clipShape(Circle()).padding()
            
            Spacer()
            
            Grid {
                ForEach(animais) { animal in
                    GridRow {
                        Text(animal.nome).bold()
                        Text(String(format: "%.1f Km/h ate %.1fKm/h", animal.min, animal.max))
                        Circle().foregroundColor(animal.cor)
                    }
                }
            }.frame(height:200).aspectRatio(
                contentMode: .fill
            ).padding().background(.black).cornerRadius(15)
        }.padding().background(background)
    }
}

#Preview {
    ContentView()
}

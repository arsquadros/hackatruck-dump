//
//  ContentView.swift
//  jp_desafio06
//
//  Created by Turma02-16 on 21/03/25.
//

import SwiftUI

struct ContentView: View {
    @State private var mostra = false
    var body: some View {
        NavigationStack {
            VStack {
                Text("Inicio").font(.largeTitle).bold()
                
                Spacer()
                
                VStack {
                    NavigationLink(destination: Pagina1View()) {
                        Text("Pagina1").frame(
                            width: 200, height: 75
                        ).background(.red)
                    }
                    
                    NavigationLink(destination: Pagina2View()) {
                        Text("Pagina2").frame(
                            width: 200, height: 75
                        ).background(.red)
                    }
                    
                    Button(action: {
                        mostra.toggle()
                    }) {
                        Text("Pagina3").frame(
                            width: 200, height: 75
                        ).background(.red)
                    }.sheet(isPresented: $mostra) {
                        Pagina3View()
                    }
                }
                
                Spacer()
            }
        }.tint(.black)
    }
}

#Preview {
    ContentView()
}

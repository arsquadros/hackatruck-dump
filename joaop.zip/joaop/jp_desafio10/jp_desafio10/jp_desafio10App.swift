//
//  jp_desafio10App.swift
//  jp_desafio10
//
//  Created by Turma02-16 on 27/03/25.
//

import SwiftUI

@main
struct jp_desafio10App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

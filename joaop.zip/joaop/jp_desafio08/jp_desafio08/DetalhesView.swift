//
//  DetalhesView.swift
//  jp_desafio08
//
//  Created by Turma02-16 on 25/03/25.
//

import SwiftUI

struct DetalhesView: View {
    @State var foto:String? = "teste"
    @State var nome:String? = "teste"
    @State var descricao:String? = "teste"
    
    var body: some View {
        AsyncImage(url: URL(string:foto!))
        Text(nome!)
        Text(descricao!)
    }
}

#Preview {
    DetalhesView()
}

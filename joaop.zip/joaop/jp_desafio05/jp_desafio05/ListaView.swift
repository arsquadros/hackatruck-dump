//
//  ListaView.swift
//  jp_desafio05
//
//  Created by Turma02-16 on 21/03/25.
//

import SwiftUI

struct ListaView: View {
    var body: some View {
        NavigationStack {
            List {
                NavigationLink(destination: RosaView()) {
                    LabeledContent {
                        Image(
                            systemName: "paintbrush"
                        ).resizable().frame(
                            width:20, height: 20
                        ).padding(5)
                    } label: {
                        Text("Rosa")
                    }
                }
                
                NavigationLink(destination: AzulView()) {
                    LabeledContent {
                        Image(
                            systemName: "paintbrush.pointed"
                        ).resizable().frame(
                            width:20, height: 20
                        ).padding(5)
                    } label: {
                        Text("Azul")
                    }
                }
                
                NavigationLink(destination: CinzaView()) {
                    LabeledContent {
                        Image(
                            systemName: "paintpalette"
                        ).resizable().frame(
                            width:20, height: 20
                        ).padding(5)
                    } label: {
                        Text("Cinza")
                    }
                }
            }
        }
    }
}

#Preview {
    ListaView()
}

//
//  jp_desafio01App.swift
//  jp_desafio01
//
//  Created by Turma02-16 on 19/03/25.
//

import SwiftUI

@main
struct jp_desafio01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

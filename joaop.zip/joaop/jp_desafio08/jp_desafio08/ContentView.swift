//
//  ContentView.swift
//  jp_desafio08
//
//  Created by Turma02-16 on 25/03/25.
//

import SwiftUI
import MapKit

struct Local:Hashable {
    var nome:String
    var foto:String
    var descricao:String
    var latitude:Double
    var longitude:Double
}

struct ContentView: View {
    @State var mostra = false
    @State var mostra_detalhes = false
    @State var posicao = MapCameraPosition.region(
        MKCoordinateRegion(
            center: CLLocationCoordinate2D(
                latitude: 0,
                longitude: 0
            ),
            span: MKCoordinateSpan(
                latitudeDelta: 1,
                longitudeDelta: 1
            )
        )
    )
    @State var localizacoes = [
        Local(
            nome: "Lugar1",
            foto: "https://picsum.photos/g/200/200",
            descricao: "Descricao1",
            latitude: -19.0,
            longitude: -43.940933
        ),
        Local(
            nome: "Lugar2",
            foto: "https://picsum.photos/g/200/200",
            descricao: "Descricao2",
            latitude: -19.912998,
            longitude: -43.0
        ),
        Local(
            nome: "Lugar3",
            foto: "https://picsum.photos/g/200/200",
            descricao: "Descricao3",
            latitude: -18.912998,
            longitude: -44.940933
        ),
        Local(
            nome: "Lugar4",
            foto: "https://picsum.photos/g/200/200",
            descricao: "Descricao4",
            latitude: -18.0,
            longitude: -44.940933
        ),
        Local(
            nome: "Lugar5",
            foto: "https://picsum.photos/g/200/200",
            descricao: "Descricao5",
            latitude: -18.912998,
            longitude: -44.0
        )
    ]
    @State var selecionado:Local?
    
    var body: some View {
        ZStack {
            Map(position: $posicao).ignoresSafeArea()
            
            VStack {
                Picker("Localizacao", selection: $selecionado) {
                    ForEach(localizacoes, id:\.self) { local in
                        Button(local.nome) {
                            var _ = print("butao")
                            posicao = MapCameraPosition.region(
                                MKCoordinateRegion(
                                    center: CLLocationCoordinate2D(
                                        latitude: local.latitude,
                                        longitude: local.longitude
                                    ),
                                    span: MKCoordinateSpan(
                                        latitudeDelta: 1,
                                        longitudeDelta: 1
                                    )
                                )
                            )
                        }.tag(local as Local?)
                    }
                }.onChange(of: selecionado, {
                    var _ = print("butao")
                }).frame(
                    width: 200, height: 30
                ).background(.white).cornerRadius(10).padding(
                    .top, 10
                )
                
                Spacer()
                
                Button(action: {
                    mostra.toggle()
                }) {
                    Text("Detalhes").frame(
                        width: 200, height: 30
                    ).background(.white).cornerRadius(10).padding(
                        .bottom, 20
                    )
                }.sheet(isPresented: $mostra) {
                    DetalhesView(
                        foto: selecionado!.foto,
                        nome: selecionado!.nome,
                        descricao: selecionado!.descricao
                    )
                }
            }

        }
    }
}

#Preview {
    ContentView()
}

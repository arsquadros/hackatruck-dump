//
//  ContentView.swift
//  jp_desafio09
//
//  Created by Turma02-16 on 26/03/25.
//

import SwiftUI

class Personagem:ObservableObject {
    @Published var personagens:[PersonagemModel] = []
    
    func requisita() {
        guard let url = URL(
            string: "https://hp-api.onrender.com/api/characters/house/gryffindor"
        ) else {
            print("Invalid URL.")
            return
        }
        
        let tarefa = URLSession.shared.dataTask(
            with: url
        ) { [weak self] dado, _, erro in
            guard let dado = dado, erro == nil else {
                return
            }
            
            do {
                let parsed = try JSONDecoder().decode(
                    [PersonagemModel].self, from: dado
                )
                
                DispatchQueue.main.async {
                    self?.personagens = parsed
                }
            } catch {
                print("ERROR on decoder.")
            }
        }
        
        tarefa.resume()
    }
}

struct ContentView: View {
    @StateObject var resposta = Personagem()
    
    var body: some View {
        NavigationStack {
            ZStack {
                AsyncImage(url: URL(
                    string: "https://picsum.photos/g/400/900"
                ))
            
                List(resposta.personagens) { personagem in
                    NavigationLink(destination: PersonagemView(
                        personagem:personagem
                    )) {
                        HStack {
                            AsyncImage(
                                url: URL(string: personagem.image!)
                            ).aspectRatio(contentMode: .fit).frame(
                                width: 100, height:100
                            ).clipShape(Circle())
                            Text(personagem.name!).padding(.leading, 20)
                            Spacer()
                        }.frame(height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/)
                    }
                }.onAppear {
                    if resposta.personagens.isEmpty {
                        Task {
                            resposta.requisita()
                        }
                    }
                }.padding(.top, 200)
            }.ignoresSafeArea(.all)
        }
    }
}

#Preview {
    ContentView()
}

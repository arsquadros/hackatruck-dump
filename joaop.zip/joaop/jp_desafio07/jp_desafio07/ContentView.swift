//
//  ContentView.swift
//  jp_desafio07
//
//  Created by Turma02-16 on 24/03/25.
//

import SwiftUI

struct Linha: View {
    @State var musica:String
    @State var artista:String
    @State var capa:String
    
    var body: some View {
        HStack(alignment: .center) {
            AsyncImage(
                url: URL(string: capa),
                content: { image in
                    image.resizable().frame(
                        width: 50, height: 50
                    )
                }, placeholder: {
                    Image(
                        systemName: "questionmark.app.fill"
                    ).resizable().frame(
                        width: 50, height: 50
                    )
                }
            )
            
            VStack(alignment: .leading) {
                Text(musica).font(.title3)
                Text(artista).font(.body)
            }
            
            Spacer()
            
            Image(systemName:"ellipsis").multilineTextAlignment(
                .trailing
            ).padding()
        }.padding(EdgeInsets(
            top: 0, leading: 20, bottom: 0, trailing: 20
        ))
    }
}

struct Card: View {
    @State var musica:String
    @State var capa:String
    
    var body: some View {
        VStack {
            AsyncImage(
                url: URL(string: capa),
                content: { image in
                    image.resizable().frame(
                        width: 200, height: 200
                    )
                }, placeholder: {
                    Image(
                        systemName: "questionmark.app.fill"
                    ).resizable().frame(
                        width: 200, height: 200
                    )
                }
            )
            
            Text(musica)
        }
    }
}

struct Musica: Identifiable {
    var id:Int
    var nome:String
    var artista:String
    var capa:String
}

struct ContentView: View {
    @State var musicas = [
        Musica(id:0, nome:"Musica1", artista:"Artista1", capa:"https://picsum.photos/g/200/200/"),
        Musica(id:1, nome:"Musica2", artista:"Artista2", capa:"https://picsum.photos/g/200/200/"),
        Musica(id:2, nome:"Musica3", artista:"Artista3", capa:"https://picsum.photos/g/200/200/"),
        Musica(id:3, nome:"Musica4", artista:"Artista4", capa:"https://picsum.photos/g/200/200/"),
        Musica(id:4, nome:"Musica5", artista:"Artista5", capa:"https://picsum.photos/g/200/200/"),
        Musica(id:5, nome:"Musica6", artista:"Artista6", capa:"https://picsum.photos/g/200/200/"),
        Musica(id:6, nome:"Musica7", artista:"Artista7", capa:"https://picsum.photos/g/200/200/"),
        Musica(id:7, nome:"Musica8", artista:"Artista8", capa:"https://picsum.photos/g/200/200/"),
        Musica(id:8, nome:"Musica9", artista:"Artista9", capa:"https://picsum.photos/g/200/200/"),
        Musica(id:9, nome:"Musica0", artista:"Artista0", capa:"https://picsum.photos/g/200/200/")
    ]

    var body: some View {
        NavigationStack {
            ScrollView {
                AsyncImage(
                    url: URL(
                        string: "https://picsum.photos/g/350/350/"
                    ),
                    content: { image in
                        image.resizable().frame(
                            width: 350, height: 350, alignment: .center
                        ).padding().foregroundColor(.white)
                    }, placeholder: {
                        Image(
                            systemName: "questionmark.app.fill"
                        ).resizable().frame(
                            width: 350, height: 350, alignment: .center
                        ).padding().foregroundColor(.white)
                    }
                )
                
                VStack(alignment: .leading, spacing: 5) {
                    Text("Playlist").font(
                        .largeTitle
                    ).foregroundColor(.white)
                    HStack(alignment: .center, spacing: 15) {
                        Image(
                            systemName: "person.crop.artframe"
                        ).resizable().frame(
                            width: 40, height: 40
                        ).font(.title2).foregroundColor(.white)
                        
                        Text("Perfil").font(.title).foregroundColor(
                            .white
                        )
                        
                        Spacer()
                    }
                }.padding(.leading, 20)
                
                VStack {
                    ForEach(musicas, id:\.id) { faixa in
                        NavigationLink(
                            destination: MusicaView(
                                musica:faixa.nome,
                                artista: faixa.artista,
                                capa: faixa.capa
                            )
                        ) {
                            Linha(
                                musica: faixa.nome,
                                artista: faixa.artista,
                                capa: faixa.capa
                            )
                        }
                    }
                }.padding(.bottom, 20)
                
                ScrollView(.horizontal) {
                    HStack {
                        ForEach(musicas, id:\.id) { faixa in
                            Card(
                                musica:faixa.nome,
                                capa:faixa.capa
                            )
                        }
                    }.padding([.leading, .trailing], 20)
                }
            }.background(
                LinearGradient(gradient: Gradient(
                    colors: [.blue, .black, .black]
                ), startPoint: .top, endPoint: .bottom)
            )
        }.tint(.white)
    }
}

#Preview {
    ContentView()
}

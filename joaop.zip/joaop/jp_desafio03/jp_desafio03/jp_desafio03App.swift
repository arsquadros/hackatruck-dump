//
//  jp_desafio03App.swift
//  jp_desafio03
//
//  Created by Turma02-16 on 19/03/25.
//

import SwiftUI

@main
struct jp_desafio03App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

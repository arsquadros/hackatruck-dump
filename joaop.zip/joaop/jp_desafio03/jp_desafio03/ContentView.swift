//
//  ContentView.swift
//  jp_desafio03
//
//  Created by Turma02-16 on 19/03/25.
//

import SwiftUI

struct ContentView: View {
    @State private var nome:String = ""
    @State private var showingAlert:Bool = false
    @State private var title:String = "Olá"
    var body: some View {
        
        ZStack {
            AsyncImage(
                url:URL(string:"https://picsum.photos/200/500"),
                content: { image in
                    image.resizable().aspectRatio(
                        contentMode: .fit
                    ).edgesIgnoringSafeArea(.all)
                }, placeholder: {}
            ).scaledToFill().opacity(0.3)
            
            VStack {
                Text(title)
                TextField("Entre com seu nome: ", text: $nome).onSubmit {
                    title += ", " + nome
                }.multilineTextAlignment(.center)
                
                Spacer()
                
                AsyncImage(
                    url:URL(string:"https://picsum.photos/300/200")
                )
                
                Spacer()
                
                Button("Show Alert") {
                    showingAlert = true
                }.alert("Important message", isPresented: $showingAlert) {
                    Button("OK", role: .cancel) { }
                }
            }
        }
    }
}

#Preview {
    ContentView()
}

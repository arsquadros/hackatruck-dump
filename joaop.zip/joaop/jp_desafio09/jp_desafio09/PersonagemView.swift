//
//  PersonagemView.swift
//  jp_desafio09
//
//  Created by Turma02-16 on 26/03/25.
//

import SwiftUI

struct PersonagemView: View {
    @State var personagem:PersonagemModel?
    
    var body: some View {
        VStack {
            AsyncImage(
                url: URL(string: personagem!.image!),
                content: { image in
                    image.resizable().frame(
                        width: 300, height: 300, alignment: .center
                    ).padding().foregroundColor(.white)
                }, placeholder: {
                    Image(
                        systemName: "questionmark.app.fill"
                    ).resizable().frame(
                        width: 300, height: 300, alignment: .center
                    ).padding().foregroundColor(.white)
                }
            )
            
            ScrollView {
                Text(personagem!.name!).font(.title2).foregroundColor(.white)
                ForEach(personagem!.alternate_names!, id:\.self) { nome in
                    Text(nome).font(.title2).foregroundColor(.white)
                }
                Text(personagem!.species!).font(.title2).foregroundColor(.white)
                Text(personagem!.gender!).font(.title2).foregroundColor(.white)
                Text(personagem!.house!).font(.title2).foregroundColor(.white)
                Text(personagem!.dateOfBirth!).font(.title2).foregroundColor(.white)
                Text(String(personagem!.yearOfBirth!)).font(.title2).foregroundColor(.white)
                Text(personagem!.wizard! ? "Sim" : "Não").font(.title2).foregroundColor(.white)
                Text(personagem!.ancestry!).font(.title2).foregroundColor(.white)
                Text(personagem!.eyeColour!).font(.title2).foregroundColor(.white)
                Text(personagem!.hairColour!).font(.title2).foregroundColor(.white)
                Text(
                    "\(personagem!.wand.wood!) \(personagem!.wand.core!) \(personagem!.wand.length!)"
                ).font(.title2).foregroundColor(.white)
                Text(personagem!.patronus!).font(.title2).foregroundColor(.white)
                Text(String(personagem!.hogwartsStudent!)).font(.title2).foregroundColor(.white)
                Text(String(personagem!.hogwartsStaff!)).font(.title2).foregroundColor(.white)
                Text(personagem!.actor!).font(.title2).foregroundColor(.white)
                ForEach(personagem!.alternate_actors!, id:\.self) { nome in
                    Text(nome).font(.title2).foregroundColor(.white)
                }
                Text(String(personagem!.alive!)).font(.title2).foregroundColor(.white)
            }
        }.frame(maxWidth: .infinity).background(
            LinearGradient(gradient: Gradient(
                colors: [.blue, .black, .black]
            ), startPoint: .top, endPoint: .bottom)
        )
    }
}

#Preview {
    PersonagemView()
}

//
//  Camera_SwiftUIApp.swift
//  ProjetoIdosos
//
//  Created by Turma02-6 on 04/04/25.
//

import SwiftUI

@main
struct Camera_SwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

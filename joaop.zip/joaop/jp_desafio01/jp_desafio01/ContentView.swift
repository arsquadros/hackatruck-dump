//
//  ContentView.swift
//  jp_desafio01
//
//  Created by Turma02-16 on 19/03/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            HStack {
                Rectangle().frame(
                    width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 100
                )
                
                Spacer()
                
                Rectangle().frame(
                    width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 100
                )
            }
            
            Spacer()
            
            HStack {
                Rectangle().frame(
                    width: 100, height: 100
                )
                
                Spacer()
                
                Rectangle().frame(
                    width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 100
                )
            }
        }.padding()
    }
}

#Preview {
    ContentView()
}

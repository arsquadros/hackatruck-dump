//
//  jp_desafio06App.swift
//  jp_desafio06
//
//  Created by Turma02-16 on 21/03/25.
//

import SwiftUI

@main
struct jp_desafio06App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

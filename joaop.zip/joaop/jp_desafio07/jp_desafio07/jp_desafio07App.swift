//
//  jp_desafio07App.swift
//  jp_desafio07
//
//  Created by Turma02-16 on 24/03/25.
//

import SwiftUI

@main
struct jp_desafio07App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

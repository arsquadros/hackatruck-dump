//
//  jp_desafio02App.swift
//  jp_desafio02
//
//  Created by Turma02-16 on 19/03/25.
//

import SwiftUI

@main
struct jp_desafio02App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
